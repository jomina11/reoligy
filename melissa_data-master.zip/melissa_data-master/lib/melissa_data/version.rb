module MelissaData
  VERSION = "0.2.13"
end
